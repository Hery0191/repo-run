import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, base64
import xbmcaddon
from addon.common.addon import Addon
import requests
import urlresolver
from metahandler import metahandlers  #####added meta module
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.openhub'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/icons/'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
BASEURL = base64.b64decode ('aHR0cDovL29wZW5odWIucHcv')
metaset = selfAddon.getSetting('enable_meta')  
metaget = metahandlers.MetaData()

def MENU():
    addDir('[B][COLOR darkturquoise]Trending[/COLOR][/B]',BASEURL + base64.b64decode ('dHJlbmRpbmcvP2dldD1tb3ZpZXM='),5,ART + 'trend.png',FANART,'')
    addDir('[B][COLOR aqua]All Movies[/COLOR][/B]',BASEURL + base64.b64decode ('bW92aWVzLw=='),5,ART + 'all_mov.png',FANART,'')
    addDir('[B][COLOR cyan]Genres[/COLOR][/B]',BASEURL + base64.b64decode ('Z2VucmUv'),3,ART + 'genres.png',FANART,'')
    addDir('[B][COLOR turquoise]Release Year[/COLOR][/B]',BASEURL + base64.b64decode ('cmVsZWFzZS8='),4,ART + 'release.png',FANART,'')
    addDir('[B][COLOR aquamarine]Top Imdb[/COLOR][/B]',BASEURL + base64.b64decode ('dG9wLWltZGIv'),7,ART + 'imdb.png',FANART,'')
    addDir('[B][COLOR teal]Search[/COLOR][/B]','url',6,ART + 'search.png',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content(url):      #####cleaned name/title scrape to gain year
    OPEN = Open_Url(url)
    Regex = re.compile('<article id=.+?class="item movies".+?href="(.+?)"><img src="(.+?)" alt="(.+?)".+?</h3>.+?<span>(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,icon,title,year in Regex:
            items = len(Regex)
            if '(' in title:
                title = title.split(' (')[0]
            title = title.replace('&#8217;','\'').replace('#038;','').replace('\\xc3\\xa9','e').replace('&#8211;','-')
            name = title + ' (' + year + ')'
            if metaset=='true':
                addDir2('[B][COLOR springgreen]%s[/COLOR][/B]' %name,url,100,icon,items)
            else:
                addDir('[B][COLOR springgreen]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    np = re.compile('class="current".+?href=\'(.+?)\'',re.DOTALL).findall(OPEN)
    for url in np:
                    addDir('[B][COLOR royalblue]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    setView('movies', 'movie-view')

    
def Get_Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="genres scrolling">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)"',re.DOTALL).findall(str(Regex))
    for url in Regex2:
        name = url.split('/')[4]
        name = name.split('/')[0].split('.')[0].title()
        addDir('[B][COLOR springgreen]%s[/COLOR][/B]' %name,url,5,ART + 'genres.png',FANART,'')   #####corrected art
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_Years(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="year scrolling">(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<li><a href="(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
            addDir('[B][COLOR springgreen]%s[/COLOR][/B]' %name,url,5,ART + 'release.png',FANART,'')   #####corrected art
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_imdb(url):
    OPEN = Open_Url(url)
    Regex = re.compile('</i> Movies</h3>(.+?)<div class="top-imdb-list">',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<div class="image">.+?<img src="(.+?)" /></a>.+?<a href="(.+?)">(.+?)</a></div>',re.DOTALL).findall(str(Regex))
    for icon,url,name in Regex2:
            icon = icon.replace('-90x135','')    #####made are show correctly
            name = name.replace('&#8211;','-').replace('#038;','').replace('\\xc3\\xa9','e').replace('&#8217;','\'')
            addDir('[B][COLOR springgreen]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = BASEURL + '/?s=' + search
                search_res(url)
    
def search_res(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="result-item">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?<span class="year">(.+?)</span>',re.DOTALL).findall(OPEN)
    for url,icon,title,year in Regex:
            items = len(Regex)
            icon = icon.replace('-90x135','').replace('-150x150','').replace('w90','w300_and_h450_bestv2')
            title = title.replace('&#8217;','\'').replace('#038;','').replace('\\xc3\\xa9','e').replace('&#8211;','-')
            name = title + ' (' + year + ')'
            if '/tvshows/' not in url:
                if metaset=='true':
                    addDir2('[B][COLOR springgreen]%s[/COLOR][/B]' %name,url,100,icon,items)
                else:
                    addDir('[B][COLOR springgreen]%s[/COLOR][/B]' %name,url,100,icon,FANART,'')
    setView('movies', 'movie-view')
    
def RESOLVE(url):
    OPEN = Open_Url(url)
    url = re.compile('<iframe class=.+?src="(.+?)">',re.DOTALL).findall(OPEN)[0]
    try:
        stream_url=urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title": name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addDir2(name,url,mode,iconimage,itemcount):
        name = name.replace('[B][COLOR springgreen]','').replace('[/COLOR][/B]','')
        splitName=name.partition('(')
        simplename=""
        simpleyear=""
        if len(splitName)>0:
            simplename=splitName[0]
            simpleyear=splitName[2].partition(')')
        if len(simpleyear)>0:
            simpleyear=simpleyear[0]
        meta = metaget.get_meta('movie',simplename,simpleyear)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=iconimage
        name = '[B][COLOR springgreen]' + name + '[/COLOR][/B]'
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 99, 'url':meta['trailer']})))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image',FANART)
        if mode==100:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok

def notification(title, message, icon):
        addon.show_small_popup( addon.get_name(), message.title(), 5000, icon)
        return
    
def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'List':
            VT = '50'
        elif addon.get_setting(viewType) == 'Default Menu View':
            VT = addon.get_setting('default-view1')
        elif addon.get_setting(viewType) == 'Default TV Shows View':
            VT = addon.get_setting('default-view2')
        elif addon.get_setting(viewType) == 'Default Episodes View':
            VT = addon.get_setting('default-view3')
        elif addon.get_setting(viewType) == 'Default Movies View':
            VT = addon.get_setting('default-view4')
        elif addon.get_setting(viewType) == 'Default Docs View':
            VT = addon.get_setting('default-view5')
        elif addon.get_setting(viewType) == 'Default Cartoons View':
            VT = addon.get_setting('default-view6')
        elif addon.get_setting(viewType) == 'Default Anime View':
            VT = addon.get_setting('default-view7')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

def PT(url):
        addon.log('Play Trailer %s' % url)
        notification( addon.get_name(), 'fetching trailer', addon.get_icon())
        xbmc.executebuiltin("PlayMedia(%s)"%url)

params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None




try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 3 : Get_Genres(url)
elif mode == 4 : Get_Years(url)
elif mode == 5 : Get_content(url)
elif mode == 7 : Get_imdb(url)
elif mode == 6 : Search()
elif mode==99: PT(url)
elif mode ==100: RESOLVE(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

















